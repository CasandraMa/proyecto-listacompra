
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="listshopping.css">

    <title>Lista de Compra</title>
</head>
<body>
    <h1>Lista de Compra</h1>

    <!-- Creo un menu para seleccionar las opciones -->

    <ul class="nav nav-tabs">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="table.php">Show list</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="iinsert.php">Insert</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="modify.php">Modify</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="delete.php">Delete</a>
        </li>
    </ul>

    <?php
include("listshopping.php");
 $_SESSION['carrito'];
// $matriz = array(
//     array("nombre" => "leche", "cantidad" => 6, "precio" =>0.85, "total"=> calculate_Total_Price_Product(6,0.85)),
//     array("nombre" => "cacao", "cantidad" => 2, "precio" =>1, "total"=> calculate_Total_Price_Product(2,1)),
//     array("nombre" => "avellanas", "cantidad" => 3, "precio" =>0.5, "total"=> calculate_Total_Price_Product(3,0.5)),
// );



if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    
    if (isset($_POST["nombre"])) {
        $nombre = $_POST["nombre"];
        $cantidad = $_POST["cantidad"];
        $precio = $_POST["precio"];
    modificar($nombre, $cantidad, $precio, $_SESSION['carrito']);
    }
    else{
        echo "<h3>No se recibio el nombre del producto</h3>";
    }
}
show($_SESSION['carrito']);



?>

    <!-- Contenedor donde guardo la informacion de las distintas opciones de las pestañas. -->
<nav class= "contenedor">

    <!-- Formulario para guardar un nuevo articulo -->
    <nav id="modify">
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="mb-3">
                <label for="nombre" class="form-label">Name</label>
                <?php nombresproductos($_SESSION['carrito']); ?>
                <label for="cantidad" class="form-label">Quantity</label>
                <input type="number" class="form-control" id="cantidad"  name="cantidad">
                <label for="precio" class="form-label">Price</label>
                <input type="text" class="form-control" id="precio"  name="precio"></br>
                <button type="submit" class="btn btn-primary">Change</button>
        </form>
    </nav>


</nav>






    

</body>
</html>
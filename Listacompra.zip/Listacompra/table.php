<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="listshopping.css">

    <title>Lista de Compra</title>
</head>
<body>
    <style>
        
    </style>
    <h1>Lista de Compra</h1>

    <!-- Creo un menu para seleccionar las opciones -->

    <ul class="nav nav-tabs">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="table.php">Show list</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="iinsert.php">Insert</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="modify.php">Modify</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#delete.php">Delete</a>
        </li>
    </ul>

    <!-- Contenedor donde guardo la informacion de las distintas opciones de las pestañas. -->
<nav class= "contenedor">

    <!-- Tabla generada para mostrar la lista -->
    <nav id="show">
   
    </nav>

   <?php
   include("listshopping.php");
    $matriz = $_SESSION['carrito'];
    show($matriz);
   ?>




</nav>




    

</body>
</html>
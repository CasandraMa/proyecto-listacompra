<?php

// Creamos el caririto con informacion, este era cuando lo creemos pro primera vez

$matriz = array(
    array("nombre" => "Leche", "cantidad" => 6, "precio" =>0.85, "total"=> calculate_Total_Price_Product(6,0.85)),
    array("nombre" => "Cacao", "cantidad" => 2, "precio" =>1, "total"=> calculate_Total_Price_Product(2,1)),
    array("nombre" => "Avellanas", "cantidad" => 3, "precio" =>0.5, "total"=> calculate_Total_Price_Product(3,0.5)),
);

// iniciamos una sesion que sera el que guarde la información entre ficheros solo se iniciara aqui porque esta pagina sera a la que llamen las demas
session_start();
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = $matriz;

}



//mostrar en la tabla 
function show($matriz){
    echo" <table class='table'>";
    echo "<tr> ";
        echo "  <th>Name</th>";
        echo "  <th>Quantity</th>";
        echo "  <th>Precio</th>";
        echo "  <th>Total</th>";
    echo "</tr>";
    if(!empty($matriz)){
        foreach ($matriz as $producto) {
            echo "<tr> ";
                echo "<td> ".$producto["nombre"] ."</td>";
                echo "<td> ".$producto["cantidad"] ."</td>";
                echo "<td>" .$producto["precio"]."</td>";
                echo "<td>" .$producto["total"]  ."€</td>";
            echo "</tr>";
        }

        echo "<tr> ";
        echo "  <th colspan=3>Subtotal</th>";

        echo "<th >".calculate_Total_Purchase_Price($matriz)."€</th>";

        echo "</tr>";
    }
    else{
        echo "La lista esta vacia";
    }
        
echo"</table>";
}


// Comprueba si existe ya el producto
function comprobar($name,$matriz){
    $existproduct = false;
    for ($i = 0; $i < count($matriz); $i++) {
        if ($matriz[$i]['nombre'] === $name){
            $existproduct = true;
            break;
        }
        
    }

    return $existproduct;

    
}

// Calculo el precio por la cantidad para añadirlo desde insertar o modificar
function calculate_Total_Price_Product($quant,$price){
    return $quant * $price;
}

//Cuando vaya a visualizarse la lista se vera el total de la compra

function calculate_Total_Purchase_Price($matriz){
    $totalamount = 0;
    foreach ($matriz as $producto) { 
        $totalamount += $producto["total"];
    }
    return $totalamount;
    
}

//inserta la informacion despues de comprobar que el producto no se encuentra y se guarda en el carrito

function insertar($name, $quant, $price, $matriz){
    $name = ucfirst(strtolower($name));
    $resultado = comprobar($name,$matriz);
    if ($resultado === false){
        $lista= array("nombre" => $name, "cantidad" => $quant, "precio" =>$price, "total"=> calculate_Total_Price_Product($quant,$price));
        array_push($matriz,$lista);
        $_SESSION['carrito'] = $matriz;
    
    }
    else{
        echo "<h1>El producto ya existe</h1>";
      
    }
    return $matriz;
}


//modifica la informacion despues de comprobar que el producto  se encuentra y se guarda el cambio en el carrito
function modificar($name, $quant, $price,$matriz){
    $name = ucfirst(strtolower($name));
    $resultado = comprobar($name,$matriz);
    if ($resultado === true){
        for ($i=0; $i < sizeof($matriz) ; $i++) {
            if ($matriz[$i]["nombre"] === $name){ 
                $matriz[$i]["cantidad"] = $quant;
                $matriz[$i]["precio"] = $price;
                $matriz[$i]["total"] = calculate_Total_Price_Product($quant,$price);
            }

        }
      
        $_SESSION['carrito'] = $matriz;
    }
    else{
        echo "<h1>El producto no existe lo que quieres es insertar un nuevo producto</h1>";
    }
}

// Listado con la informacion para poder elegir las opciones en modificar y borrar

function nombresproductos($matriz){
    echo"<select class='form-select' aria-label='Default select example' name='nombre'>";
    foreach ($matriz as $producto) {
        $llave = $producto["nombre"];
       echo"<option value='$llave'>'$llave'</option>";
    }
    echo"</select>";

        
}

// elimino el archivo del listado y guado el cambio
function borrar($name,$matriz){
    $productoborrar = null;
    $name = ucfirst(strtolower($name));
    $resultado = comprobar($name,$matriz);
    if ($resultado === true){
        foreach ($matriz as $key => $producto) {
            if($producto["nombre"] === $name){
                $productoborrar = $key;
                break;  
            }
        }
        
    }

    if($productoborrar !== null){
        unset($matriz[$productoborrar]);
    }
    else{
        echo "El producto no existe asi que no se puede borrar";
    }
    $_SESSION['carrito'] = $matriz;

}
    
                


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="listshopping.css">

    <title>Lista de Compra</title>
</head>
<body>
    <h1>Lista de Compra</h1>

    <!-- Creo un menu para seleccionar las opciones -->

    <ul class="nav nav-tabs">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="table.php">Show list</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="iinsert.php">Insert</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="modify.php">Modify</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="delete.php">Delete</a>
        </li>
    </ul>

<?php
include("listshopping.php");
 $_SESSION['carrito'];



if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["nombre"])) {
        $nombre = $_POST["nombre"];
        borrar($nombre, $_SESSION['carrito']);
    }
    else{
        echo "<h3>No se recibio el nombre del producto</h3>";
    }
}
show($_SESSION['carrito']);


?>



    <!-- Contenedor donde guardo la informacion de las distintas opciones de las pestañas. -->
<nav class= "contenedor">

    <!-- Formulario para guardar un nuevo articulo -->
    <nav id="delete">
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="mb-3">
                <label for="nombre" class="form-label">Name</label>
                <?php nombresproductos($_SESSION['carrito']); ?>
                <button type="submit" class="btn btn-primary">Delete</button>
        </form>
    </nav>


</nav>




    

</body>
</html>